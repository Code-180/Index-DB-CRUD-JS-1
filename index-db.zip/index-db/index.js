//++++++++++++++++++++++++++++++++++++++++++++++++++
// Setting The Instance For IndexDB 
//++++++++++++++++++++++++++++++++++++++++++++++++++
var indexedDB = window.indexedDB || window.mozIndexedDB || window.webkitIndexedDB || window.msIndexedDB || window.shimIndexedDB,
    IDBTransaction = window.IDBTransaction || window.webkitIDBTransaction || window.msIDBTransaction;
//+++++++++++++++++++++++++++++++++++++++++++++++++++++
// DATA OBJECT
//+++++++++++++++++++++++++++++++++++++++++++++++++++++
const bikeData = [
    { id: 1, name: "Yamaha", model: "YZF R1M.", year: 2017 },
    { id: 2, name: "CBR ", model: "1000RR" },
    { id: 3, name: "Ducati", model: "Panigale V4" },
    { id: 4, name: "BMW", model: "S 1000 RR" },
    { id: 5, name: "Kawasaki", model: "Ninja ZX-10R" },
    { id: 6, name: "Kawasaki", model: "Ninja ZX-15R" },
];
//+++++++++++++++++++++++++++++++++++++++++++++++++++++
//Creating The DB 
//+++++++++++++++++++++++++++++++++++++++++++++++++++++
const request = window.indexedDB.open("MyBikeIndexDB", 1);
//+++++++++++++++++++++++++++++++++++++++++++++++++++++
//Error On Creation Of The DB or Some Other Kind Of Error 
//+++++++++++++++++++++++++++++++++++++++++++++++++++++
request.onerror = (error) => {
    console('"Why didnt you allow my web app to use IndexedDB?', error);
};
//+++++++++++++++++++++++++++++++++++++++++++++++++++++
//When you create a new database or increase the version number of an existing database.
//+++++++++++++++++++++++++++++++++++++++++++++++++++++
request.onupgradeneeded = (event) => {
    // Save the IDBDatabase interface
    const db = event.target.result;
    // Create an objectStore for this database
    const objectStore = db.createObjectStore("bikes", { keyPath: "id" });
    objectStore.createIndex("nameIndex", "name", { unique: false });
    objectStore.createIndex("modelIndex", "model", { unique: false });
};
//+++++++++++++++++++++++++++++++++++++++++++++++++++++
//On Success
//+++++++++++++++++++++++++++++++++++++++++++++++++++++
request.onsuccess = (event) => {
    //DB Instance
    db = event.target.result;
    //+++++++++++++++++++++++++++++++++++++
    //Create
    //+++++++++++++++++++++++++++++++++++++
    const bikeObjectStore = db.transaction("bikes", "readwrite").objectStore("bikes");
    bikeData.forEach((bike) => {
        //console.log(bike);
        bikeObjectStore.add(bike);
    });
    //+++++++++++++++++++++++++++++++++++++
    //Geeting The Data
    //+++++++++++++++++++++++++++++++++++++
    const transaction = db.transaction(["bikes"]);
    const store = transaction.objectStore("bikes");
    const nameIndex = store.index("nameIndex");
    const modelIndex = store.index("modelIndex");
    //+++++++++++++++++++++++++++++++++++++
    //Query-1
    //+++++++++++++++++++++++++++++++++++++
    const idQuery = store.get(4);
    const nameQuery = nameIndex.getAll("Kawasaki");
    const makeQuery = modelIndex.get("1000RR");

    idQuery.onerror = (event) => {
        // Handle errors!
    };
    idQuery.onsuccess = (event) => {
        console.log(idQuery.result);
    };

    nameQuery.onerror = (event) => {
        // Handle errors!
    };
    nameQuery.onsuccess = (event) => {
        console.log(nameQuery.result);
    };

    makeQuery.onerror = (event) => {
        // Handle errors!
    };
    makeQuery.onsuccess = (event) => {
        console.log(makeQuery.result);
    };
    //+++++++++++++++++++++++++++++++++++++
    //Query-2
    //+++++++++++++++++++++++++++++++++++++
    db.transaction("bikes").objectStore("bikes").get(1).onsuccess = (event) => {
        console.log(event.target.result);
    };
    //+++++++++++++++++++++++++++++++++++++
    //Update
    //+++++++++++++++++++++++++++++++++++++
    const objectStoreUpdate = db.transaction(["bikes"], "readwrite").objectStore("bikes");
    const requestMainUpdate = objectStoreUpdate.get(4);
    requestMainUpdate.onerror = (event) => {
        // Handle errors!
    };
    requestMainUpdate.onsuccess = (event) => {
        // Get the old value that we want to update
        const data = event.target.result;
        // update the value(s) in the object that you want to change
        data.name = 'Royal Enfield';
        // Put this updated object back into the database.
        const requestUpdate = objectStoreUpdate.put(data);
        requestUpdate.onerror = (event) => {
            console.log('Data Has Not Been Updated');
        };
        requestUpdate.onsuccess = (event) => {
            console.log('Data Has Been Updated');
        };
    };
    //+++++++++++++++++++++++++++++++++++++
    //Delet Query
    //+++++++++++++++++++++++++++++++++++++
    const request = db.transaction(["bikes"], "readwrite").objectStore("bikes").delete(1);
    request.onsuccess = (event) => {
        console.log('Data Deleted!!!!!!!!!');
    };
    transaction.oncomplete = function () {
        db.close();
    }

};